import React from 'react'
import '../App.css'
import Footer from '../components/footer/Footer'

export default function Products() {
    return (
        <>
        <h1 className="products">PRODUCTS</h1>
        <p className='no-content'>Add Some Content</p>
        <Footer />
        </>
    )
}
