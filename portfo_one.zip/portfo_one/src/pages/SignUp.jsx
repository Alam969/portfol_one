import React from 'react'
import '../App.css'
import Footer from '../components/footer/Footer'

export default function SignUp() {
    return (
        <>
        <h1 className="sign-up">SIGN UP</h1>
        <p className='no-content'>Add Some Content</p>
        <Footer />
        </>
    )
}
